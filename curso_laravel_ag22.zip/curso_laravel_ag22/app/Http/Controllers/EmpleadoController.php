<?php

namespace App\Http\Controllers;

use App\Empleado;
use Illuminate\Http\Request;
use Illuminate\Validation\Rule;
use GuzzleHttp\Client as HttpClient;

class EmpleadoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function __contruct(){
        //$this->middleware('auth');
    }


    public function index()
    {
        $empleados = Empleado::orderBy('id', 'DESC')->get();
        //dd($empleados);
        return view('Empleado.index',compact('empleados'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $currencyWS = $this->wsMonedas();
        $listMonedas = explode(";" , $currencyWS);
        return view('Empleado.create',compact('listMonedas'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'nombre' => 'required',
            'apellido_paterno' => 'required',
            'apellido_materno' => 'required',
            'correo' => 'required | email',//Formato Correo
            'fecha_nacimiento' => 'nullable | date | before:today',
            'direccion' => 'nullable',
            'genero' => 'required',
            'telefono' => 'required',
            'sueldo' => 'required',
            'tipo_moneda' => 'required'
        ]);

        //dd($request->all());

        $arraySave = [
            'nombre' => $request->get("nombre"),
            'apellido_paterno' => $request->get("apellido_paterno"),
            'apellido_materno' => $request->get("apellido_materno"),
            'correo' => $request->get("correo"),
            'fecha_nacimiento' => $request->get("fecha_nacimiento"),
            'direccion' => $request->get("direccion"),
            'genero' => $request->get("genero"),
            'telefono' => $request->get("telefono"),
            'codigo_empleado' => $request->get("codigo_empleado"),
            'sueldo' => $request->get("sueldo"),
            'tipo_moneda' => $request->get("tipo_moneda"),
        ];

        $saveEmpleado = Empleado::create($arraySave);
        return redirect()->route('empleado.index')->with('success','Registro creado exitosamente.');
        //dd($saveEmpleado);
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */

     
    public function show($id)
    {
        $empleado = Empleado::find($id);
        //$estadosWS = $this->wsEstados();
        //$estadosList = ((array)$estadosWS->data)['lst_estado_proveedor'];
        //dd(((array)$estadosWS->data)['lst_estado_proveedor']);
        //dd($empleado->datosContacto);
        return view('Empleado.show',compact('empleado'/*, 'estadosList'*/));
    }
    

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function edit($empleado)
    {
        $editEmpleado=Empleado::find($empleado);
        $currencyWS = $this->wsMonedas();
        $listMonedas = explode(";" , $currencyWS);
        return view('Empleado.edit',compact("editEmpleado","listMonedas"));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {

        $this->validate($request,[
            'nombre' => 'required',
            'apellido_paterno' => 'required',
            'apellido_materno' => 'required',
            'correo' => 'required | email',
            'fecha_nacimiento' => 'nullable | date | before:today',
            'direccion' => 'nullable',
            'genero' => 'required',
            'telefono' => 'required',
            'sueldo' => 'required',
            'tipo_moneda' => 'required',
        ]);

        Empleado::find($id)->update($request->all());
        return redirect()->route('empleado.index')->with('success','Registro actualizado');
    }
    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Empleado  $empleado
     * @return \Illuminate\Http\Response
     */
    public function destroy($idEmpleado)
    {
        Empleado::find($idEmpleado)->delete();
        return redirect()->route('empleado.index')->with('success' , 'Registro eliminado existosamente.');
    }

    private function wsMonedas(){
        $client = new HttpClient(['base_uri' => 'https://fx.currencysystem.com/webservices/CurrencyServer5.asmx/','verify' => false]);
        $response = $client->request('GET',"AllCurrencies",['query' => 'licenseKey=']);
        return xmlrpc_decode($response->getBody()->getContents());
    }

    /*
    private function wsEstados(){}
        // Create a client with a base URI
        $client = new HttpClient(['base_uri' => 'https://beta-bitoo-back.azurewebsites.net/api/']);
        $response = $client->request('POST', 'proveedor/obtener/lista_estados');

        return json_decode($response->getBody());
    }
    */

}