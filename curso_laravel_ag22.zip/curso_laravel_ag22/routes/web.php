<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home/visitante', 'HomeController@index')->name('home');

Route::get('/empleado/index', 'EmpleadoController@index')->name('empleado.index');

Route::get('empleado/{empleado}/show','EmpleadoController@show')->name('empleado.show');

//Route::get('/empleado/create', 'EmpleadoController@create')->name('empleado.create')->middleware("editDeleteCreate.admin");
Route::get('/empleado/create', 'EmpleadoController@create')->name('empleado.create');

Route::post('/empleado/store', 'EmpleadoController@store')->name('empleado.store');

Route::delete('/empleado/{empleado}', 'EmpleadoController@destroy')->name('empleado.destroy');

Route::get('/empleado/edit/{editEmpleado}', 'EmpleadoController@edit')->name('empleado.edit');

Route::put('empleado/{emppleado}','EmpleadoController@update')->name('empleado.update');


Route::post('/changeLang', 'HomeController@changeLang')->name('changeLang');
Route::get('/changeLangGET/{locale_id}', 'HomeController@changeLangGet')->name('changeLangGET');

//Rutas Datos Contacto
Route::get('datoContacto/{datoContacto}/show','DatoContactoController@show')->name('datoContacto.show');

Route::post('datoContacto','DatoContactoController@store')->name('datoContacto.store');

Route::get('datoContacto/{empleado}/create','DatoContactoController@create')->name('datoContacto.create');

Route::delete('datoContacto/{datoContacto}/{empleadoId}','DatoContactoController@destroy')->name('datoContacto.destroy');