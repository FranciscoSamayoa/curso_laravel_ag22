<?php
return [

    'form_create'=>[
        'employe_code' => 'Employe code',
        'name' => 'Name',
        'lastname_1'=>'Lastname',
        'lastname_2'=>'Lastname 2',
        'birthdate' => 'Birthdate',

        'gender' => 'Gender',
        'address' => 'address',
        'email' => 'email',
        'phone' => 'Phone',
        'phone number' => 'phone number',
        'employee code' => 'employee code',
        'salary' => 'salary',
        'type of currency' => 'type of currency'
    ]
];