<?php
return [

    'form_create'=>[
        'employe_code' => 'Código empleado',
        'name' => 'Nombre',
        'lastname_1'=>'Apellido Paterno',
        'lastname_2'=>'Apellido Materno',
        'birthdate' => 'Fecha de nacimiento',
        'gender' => 'Genero',
        'address' => 'Dirección',
        'email' => 'Correo',
        'phone' => 'Telefono',
        'phone number' => 'Numero telefonico',
        'employee code' => 'Codigo empleado',
        'salary' => 'Salario',
        'type of currency' => 'Tipo de moneda'
    ]
];