@extends('layouts.app')

@section('content')
    <div class="row">
        <section class="content">
            <div class="col-md-8 col-md-offset-2">

                @if ($errors->any())
                    <div class="alert alert-danger">
                        <ul>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="panel panel-primary">
                    <div class="panel-heading">
                        <h3> Editar Empleado</h3>
                    </div>

                    <div class="panel-body">

                        <form method="POST" action="{{route('empleado.update',$editEmpleado->id)}}" role="form">

                            {{ csrf_field() }}
                            <input name="_method" type="hidden" value="PUT">
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.name') }} </label>
                                        <input type="text" id="nombre" name="nombre" placeholder="nombre" value="{{$editEmpleado->nombre}}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.lastname_1') }} </label>
                                        <input type="text" id="apellido_paterno" name="apellido_paterno" placeholder="apellido_paterno" value="{{$editEmpleado->apellido_paterno}}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.lastname_2') }} </label>
                                        <input type="text" id="apellido_materno" name="apellido_materno" placeholder="apellido_materno" value="{{$editEmpleado->apellido_materno}}">
                                    </div>
                                </div>
                            </div>
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.birthdate') }} </label>
                                        <input type="date" id="fecha_nacimiento" name="fecha_nacimiento" value="{{$editEmpleado->fecha_nacimiento}}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.gender') }} </label>
                                        <div class="radio">
                                        <label><input type="radio" id="genero" name="genero" value="masculino" {{$editEmpleado->genero=='masculino' ? 'checked="true"' : '' }} >Masculino</label>
                                        </div>
                                        <div class="radio">
                                        <label><input type="radio" id="genero" name="genero" value="Femenino" {{$editEmpleado->genero=='Femenino' ? 'checked="true"' : '' }} >Femenino</label>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.address') }} </label>
                                        <input type="direccion" id="direccion" name="direccion" placeholder="direccion" value="{{$editEmpleado->direccion}}">
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.email') }} </label>
                                        <input type="email" id="correo" name="correo" placeholder="correo" value="{{$editEmpleado->correo}}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.phone number') }} </label>
                                        <input type="telefono" id="telefono" name="telefono" placeholder="telefono" value="{{$editEmpleado->telefono}}">
                                    </div>
                                </div>
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.employee code') }} </label>
                                        <input type="codigo_empleado" id="codigo_empleado" name="codigo_empleado" placeholder="codigo_empleado" value="{{$editEmpleado->codigo_empleado}}">
                                    </div>
                                </div>
                            </div>

                            <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.salary') }} </label>
                                        <input type="sueldo" id="sueldo" name="sueldo" placeholder="sueldo" value="{{$editEmpleado->sueldo}}">
                                    </div>
                                </div>
                            
                            <div class="row">
                                <div class="col-md-4">
                                    <div class="form-group">
                                        <label> {{ trans('forms.form_create.type of currency') }} </label>
                                        <br>
                                        <select class="form-control" id="tipo_moneda" name="tipo_moneda">
                                          <option value="{{old('tipo_moneda',$editEmpleado->tipo_moneda)}}"> {{old('tipo_moneda',$editEmpleado->tipo_moneda)}}</option>
                                            @foreach($listMonedas as $moneda)
                                                <option value="{{$moneda}}">{{$moneda}}</option>
                                            @endforeach
                                        </select>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <button type="submit" class="btn btn-success"> Guardar</button>
                                <a href="{{ route('empleado.index') }}" class="btn btn-default">Atras</a>
                            </div>

                        </form>

                    </div>
                </div>
            </div>
        </section>
    </div>
@endsection